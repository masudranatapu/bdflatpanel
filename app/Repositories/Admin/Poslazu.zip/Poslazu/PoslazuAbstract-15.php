<?php
namespace App\Repositories\Admin\Poslazu;

use DB;
use Auth;
use Carbon\Carbon;
use App\Models\Agent;
use App\Models\Order;
use App\Models\Stock;
use App\Models\Booking;
use App\Models\Country;
use App\Models\Customer;
use App\Models\Dispatch;
use App\Traits\RepoResponse;
use App\Models\BookingDetails;
use App\Models\ProductVariant;
use App\Models\CustomerAddress;
use App\Models\DispatchDetails;
use App\Models\SmsNotification;
use Illuminate\Http\Request;
use App\Models\CustomerAddressType;
use Response;

class PoslazuAbstract implements PoslazuInterface
{
    use RepoResponse;
    protected $agent;
    protected $order;
    protected $booking;
    protected $address_type;
    protected $country;
    protected $dispatch;
    protected $api_key      = 'kf0ecfaac86c2c240ea14d276cee0a4d5';
    protected $api_secret   = 'sc6808fa641055ec3239521b32192b9af';

    public function __construct(Agent $agent,Booking $booking, Order $order,CustomerAddressType $address_type, Country $country, Dispatch $dispatch)
    {
        $this->agent   = $agent;
        $this->booking = $booking;
        $this->order   = $order;
        $this->address_type = $address_type;
        $this->country = $country;
        $this->dispatch = $dispatch;
    }


    public function pregReplace($txt=NULL){

        return preg_replace('/[^A-Za-z0-9]/', ' ', $txt);
  }




    public function postStore($request)
        {

            $api_key                ='kf0ecfaac86c2c240ea14d276cee0a4d5';

            $courier = DB::table('SC_COURIER')->where('PK_NO',$request->courier)->first();

            $booking    = $this->booking->find($request->booking_no);

            $booking = Booking::find($request->booking_no);
            $order =  $booking->getOrder;



            //For Poslaju
                $api_key                    = $api_key;
                $send_method                = 'pickup';
                $send_date                  = date('Y-m-d', strtotime($request->dispatch_date));
                $type                       = 'parcel';
                $declared_weight            = $request->declared_weight;
                $provider_code              = 'poslaju';
                $size                       = $request->size;
                $length                     = $request->length;
                $width                      = $request->width;
                $height                     = $request->height;
                $content_type               = $request->content_type;
                $content_description        = 'Lifestyle,Home-Health and Fitness';
                //Required, number only without currency code, ie 200 for RM 200.00
                $content_value              = '200';
                $sender_name                = $order->FROM_NAME;
                $sender_phone               = $order->FROM_MOBILE;
                $sender_email               = 'azuramart@gmail.com';
                $sender_company_name        = $order->FROM_NAME;

                //Required
                if(!empty($order->FROM_ADDRESS_LINE_1)){
                    $sender_address_line_1      = str_replace("&", ",", $order->FROM_ADDRESS_LINE_1);
                }
                else{
                    return $this->formatResponse(false, 'FROM_ADDRESS_LINE_1 FIELD IS EMPTY !','admin.order.dispatch',$request->booking_no);
                }
               // $sender_address_line_1      = $order->FROM_ADDRESS_LINE_1;
                $sender_address_line_2      = $order->FROM_ADDRESS_LINE_2;
                $sender_address_line_3      = $order->FROM_ADDRESS_LINE_3;
                $sender_address_line_4      = $order->FROM_ADDRESS_LINE_4;
                //Required
                if(!empty($request->receiver_postcode)){
                    $sender_postcode         = $request->receiver_postcode;
                }
                else {
                    $sender_postcode         = $order->FROM_POSTCODE;
                }
                $sender_city                = $order->FROM_CITY;
                $sender_state               = $order->FROM_STATE;
                $sender_country_code        = 'MY';


                if(!empty($order->DELIVERY_NAME)){
                    $receiver_name              = $order->DELIVERY_NAME;
                }
                else{
                    return $this->formatResponse(false, 'DELIVERY_NAME FIELD IS EMPTY !','admin.order.dispatch',$request->booking_no);
                }

                //Required
                if(!empty($order->DELIVERY_MOBILE)){
                    $receiver_phone             = $order->DELIVERY_MOBILE;
                }
                else{
                    return $this->formatResponse(false, 'DELIVERY_MOBILE FIELD IS EMPTY !','admin.order.dispatch',$request->booking_no);
                }

                //Required
                $receiver_email             = 'azuramart@gmail.com';
                $receiver_company_name      = NULL;
                //Required DELIVERY_ADDRESS_LINE_1
                if(!empty($order->DELIVERY_ADDRESS_LINE_1)){
                    $receiver_address_line_1      = str_replace("&", ",", $order->DELIVERY_ADDRESS_LINE_1);
                }
                else{
                    return $this->formatResponse(false, 'DELIVERY_ADDRESS_LINE_1 FIELD IS EMPTY !','admin.order.dispatch');
                }
                $receiver_address_line_2    = str_replace("&", ",", $order->DELIVERY_ADDRESS_LINE_2);

                $receiver_address_line_3    = str_replace("&", ",", $order->DELIVERY_ADDRESS_LINE_3);

                $receiver_address_line_4    = str_replace("&", ",", $order->DELIVERY_ADDRESS_LINE_4);
                //Required for domestic
                if(!empty($order->DELIVERY_POSTCODE)){
                    $receiver_postcode          = $order->DELIVERY_POSTCODE;
                }
                else{
                    return $this->formatResponse(false, 'DELIVERY_POSTCODE FIELD IS EMPTY !','admin.order.dispatch');
                }
                $receiver_city              = $order->DELIVERY_CITY;
                $receiver_state             = $order->DELIVERY_STATE;
                //Requried
                $receiver_country_code      = 'MY';
                //Post Data

                $data = "api_key=$api_key&send_method=$send_method&send_date=$send_date&type=$type&declared_weight=$declared_weight&provider_code=$provider_code&size=$size&length=$length&width=$width&height=$height&content_type=$content_type&content_description=$content_description&content_value=$content_value&sender_name=$sender_name&sender_phone=$sender_phone&sender_address_line_1=$sender_address_line_1&sender_postcode=$sender_postcode&receiver_name=$receiver_name&receiver_phone=$receiver_phone&receiver_email=$receiver_email&receiver_address_line_1=$receiver_address_line_1&receiver_address_line_2=$receiver_address_line_2&receiver_address_line_3=$receiver_address_line_3&receiver_address_line_4=$receiver_address_line_4&receiver_postcode=$receiver_postcode&receiver_country_code=$receiver_country_code";

                $post_url = 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/create_shipment';

            DB::beginTransaction();

            try {

            $exist_shipment = Dispatch::where('F_ORDER_NO',$order->PK_NO)->orderBy('PK_NO','DESC')->first();
            if(!empty($exist_shipment)){

                $dispatch_id = $exist_shipment->PK_NO;



                if($request->booking_details_no){
                    foreach ($request->booking_details_no as $key => $value) {

                        if($request->dispatch_qty[$key] > 0 ){

                            $child = new DispatchDetails();

                            $child->F_SC_ORDER_DISPATCH_NO  = $dispatch_id;

                            $child->F_BOOKING_DETAILS_NO    = $value;

                            ///CHECK POS LAJU
                            if($request->courier == 1)
                            {
                                $shipment = $this->apiPostRequest($post_url,$data);
                                $shipmentData = json_decode($shipment, TRUE);
                                $shipment_keys = $shipmentData['data']['key'];
                              //CHECK SHIPMENT
                                if(isset($shipment_keys)){

                                    //SHIPMENT CHECKOUT
                                    $checkout                   = $this->newCartCheckout($shipment_keys);

                                    $shipment                   = $this->getShipmentInfoBykey($shipment_keys);

                                    $data                       = json_decode($shipment, TRUE);

                                    $tracking_no                = $data['data'][$shipment_keys]['tracking_no'];

                                    $shipment_cost              = $data['data'][$shipment_keys]['effective_price'];

                                    $child->SHIPMENT_KEY        = $shipment_keys;

                                    $child->COURIER_TRACKING_NO = $tracking_no;

                                    $child->POSTAGE_COST        = $shipment_cost;

                                }
                                else{
                                    return $this->formatResponse(false, 'SHIPMENT NOT CREATED !','admin.order.dispatch');
                                }


                            }
                            else
                            {
                                $child->COURIER_TRACKING_NO  = $request->consignment_note;
                            }
                            $child->save();
                        }
                    }
                }

            }
            else {

            //IF NEW SHIPMENT
            $dispatch                        = new Dispatch();

            $dispatch->F_ORDER_NO            = $order->PK_NO;

            $dispatch->F_COURIER_NO          = $request->courier ?? null;
            $dispatch->COURIER_NAME          = $courier->COURIER_NAME ?? null;
            $dispatch->F_DISPATCH_BY_USER_NO = Auth::user()->id;
            $dispatch->DISPATCH_USER_NAME    = Auth::user()->username;
            $dispatch->DISPATCH_DATE         = date('Y-m-d ',strtotime($request->dispatch_date));
            $dispatch->FROM_NAME             = $order->FROM_NAME;
            $dispatch->FROM_TEL_NO           = $order->FROM_MOBILE;
            $dispatch->FROM_ADDRESS_LINE_1   = $order->FROM_ADDRESS_LINE_1;
            $dispatch->FROM_ADDRESS_LINE_2   = $order->FROM_ADDRESS_LINE_2;
            $dispatch->FROM_ADDRESS_LINE_3   = $order->FROM_ADDRESS_LINE_3;
            $dispatch->FROM_ADDRESS_LINE_4   = $order->FROM_ADDRESS_LINE_4;
            $dispatch->FROM_STATE            = $order->FROM_STATE;
            $dispatch->FROM_CITY             = $order->FROM_CITY;
            $dispatch->FROM_POST_CODE        = $order->FROM_POSTCODE;
            $dispatch->FROM_F_COUNTRY_NO     = $order->FROM_F_COUNTRY_NO;
            $dispatch->FROM_COUNTRY          = $order->FROM_COUNTRY;
           // dd($dispatch->FROM_F_COUNTRY_NO);
            $dispatch->TO_NAME               = $order->DELIVERY_NAME;
            $dispatch->TO_TEL_NO             = $order->DELIVERY_MOBILE;
            $dispatch->TO_ADDRESS_LINE_1     = $order->DELIVERY_ADDRESS_LINE_1;
            $dispatch->TO_ADDRESS_LINE_2     = $order->DELIVERY_ADDRESS_LINE_2;
            $dispatch->TO_ADDRESS_LINE_3     = $order->DELIVERY_ADDRESS_LINE_3;
            $dispatch->TO_ADDRESS_LINE_4     = $order->DELIVERY_ADDRESS_LINE_4;
            $dispatch->TO_STATE              = $order->DELIVERY_STATE;
            $dispatch->TO_CITY               = $order->DELIVERY_CITY;
            $dispatch->TO_POST_CODE          = $order->DELIVERY_POSTCODE;
            $dispatch->TO_F_COUNTRY_NO       = $order->DELIVERY_F_COUNTRY_NO;
            $dispatch->TO_COUNTRY            = $order->DELIVERY_COUNTRY;
            $dispatch->COLLECTED_BY          = $request->collected_by;
            $dispatch->save();


            if($request->booking_details_no){

                foreach ($request->booking_details_no as $key => $value) {

                    if($request->dispatch_qty[$key] > 0 ){
                        $child = new DispatchDetails();
                        $child->F_SC_ORDER_DISPATCH_NO  = $dispatch->PK_NO;
                        $child->F_BOOKING_DETAILS_NO    = $value;

                        if($request->courier == 1){

                                $shipment = $this->apiPostRequest($post_url,$data);
                                $shipmentData = json_decode($shipment, TRUE);
                                $shipment_keys = $shipmentData['data']['key'];
                            //CHECK SHIPMENT
                            if(isset($shipment_keys)){

                                //SHIPMENT CHECKOUT
                                $checkout                   = $this->newCartCheckout($shipment_keys);

                                $shipment                   = $this->getShipmentInfoBykey($shipment_keys);

                                $data                       = json_decode($shipment, TRUE);

                                $tracking_no                = $data['data'][$shipment_keys]['tracking_no'];

                                $shipment_cost              = $data['data'][$shipment_keys]['effective_price'];

                                $child->SHIPMENT_KEY        = $shipment_keys;

                                $child->COURIER_TRACKING_NO = $tracking_no;

                                $child->POSTAGE_COST        = $shipment_cost;

                            }
                            else{
                                return $this->formatResponse(false, 'SHIPMENT NOT CREATED !','admin.order.dispatch');
                            }

                        }

                        else{

                            $child->COURIER_TRACKING_NO     = $request->consignment_note;

                            $child->POSTAGE_COST     = $shipment_cost;

                        }

                        $child->save();

                        Stock::where('PK_NO', $child->F_INV_STOCK_NO)->update(['ORDER_STATUS' => 80]);

                        BookingDetails::where('PK_NO',$value)->update(['DISPATCH_STATUS' => 40]);
                    }
                }
            }


            $data = DB::table('SLS_BOOKING_DETAILS')
            ->select(DB::raw("GROUP_CONCAT(DISPATCH_STATUS) as DISPATCH_STATUS"), DB::raw("COUNT(*) AS COUNTER"))
            ->groupBy('F_BOOKING_NO')
            ->where('F_BOOKING_NO',$request->booking_no)
            ->first();

            $dispatch_status = $data->DISPATCH_STATUS;

            $dispatch_status_arr = explode(',',$dispatch_status);

            $dispatch_status_arr_count = array_count_values($dispatch_status_arr);

            if(isset($dispatch_status_arr_count[40])){

                if($dispatch_status_arr_count[40] == $data->COUNTER){

                    Order::where('F_BOOKING_NO',$request->booking_no)->update(['DISPATCH_STATUS' => 40]);

                }else{
                    /*Partially dispatched*/
                    Order::where('F_BOOKING_NO',$request->booking_no)->update(['DISPATCH_STATUS' => 35]);
                }
            }

            if(isset($tracking_no)){
                $tracking_info = $tracking_no;
            }
            else{
                $tracking_info = $request->consignment_note;
            }

            $tracking_info = $request->consignment_note;

            $sms_body = "RM0.00 AZURAMART: Order #ORD-".$booking->BOOKING_NO." has dispatched, ".$tracking_info.", for more info please Whatsapp http://linktr.ee/azuramart";


            $noti = new SmsNotification();

            $noti->TYPE = 'Dispatch';

            $noti->F_BOOKING_NO = $booking->PK_NO;

            //$noti->F_BOOKING_DETAIL_NO = $value->PK_NO;

            $noti->BODY = $sms_body;

            $noti->F_SS_CREATED_BY = Auth::user()->id;

            if($booking->IS_RESELLER == 0){
                $noti->CUSTOMER_NO = $booking->F_CUSTOMER_NO;
                $noti->IS_RESELLER = 0;
            }else{
                $noti->RESELLER_NO = $booking->F_RESELLER_NO;
                $noti->IS_RESELLER = 1;
            }
            $noti->save();


            }//IF NEW SHIPMENT END


        } catch (\Exception $e) {

            dd($e);
            DB::rollback();
            return $this->formatResponse(false,'Dispatch not successfull ','admin.order.dispatch',$request->booking_no);
           // return $this->formatResponse(false,'Dispatch not successfull ','admin.order.list');
        }
        DB::commit();
        return $this->formatResponse(true,'Dispatch successfull !','admin.order.dispatch',$request->booking_no);

        }





        public function getDispatchInfo(){


        }

















        public function getDownload($link)
    {
        return Response::download($link);
    }



        public function getConsignmentNote($tracking_no){
           //$api_key                ='kf0ecfaac86c2c240ea14d276cee0a4d5';
            $data = "api_key=kf0ecfaac86c2c240ea14d276cee0a4d5&tracking_no=$tracking_no";
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/get_consignment_note',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => $data,
              CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded',
              //  'Cookie: ci_session=gi3odq32jirlu6hvm30c26hjrab2cjtu'
              ),
            ));
            $response = curl_exec($curl);
            curl_close($curl);


            return $response;







        }


    public function createShipment($request){

          //$this->api_key;
        $api_key                ='kf0ecfaac86c2c240ea14d276cee0a4d5';
        // Required, value either [pickup] or [dropoff] only
        $send_method            = 'pickup';
        //2021-02-06
        $send_date              = date('Y-m-d');

        //Required, value either [parcel] or [document] only
        $type                   = 'parcel';
        // Required, between 0.001 to 30, 3 decimal point

        $declared_weight        = '5';

      //  Required, valid value are "poslaju", "ems" or "airparcel" only--

        $provider_code          = 'poslaju';
        //Required, only accept values from /get_parcel_sizes response
        //"flyers_s": "Flyers S","flyers_m": "Flyers M","flyers_l": "Flyers L","flyers_xl": "Flyers XL","envelope_third": "Envelope 1\/3 A4","envelope_a4": "Envelope A4","envelope_a5": "Envelope A5","box": "Box \/ Self Wrapped"
        $size                   = 'box';

       // Required for size [box]
        $length                 = '100';

       // Required for size [box]
        $width                  = '20';

        //Required for size [box]
        $height                 = '10';

        //Required, only accept values from /get_content_types endpoint
        $content_type           = 'general';

        //Required
        $content_description    = 'test content description';

        //Required, number only without currency code, ie 200 for RM 200.00
        $content_value          = '200';

        //Required
        $sender_name            = 'AZURAMART';

        //Required
        $sender_phone           = '+60174258105';

        $sender_email           = 'azuramart@gmail.com';

        $sender_company_name    = 'AZURAMART';

        //Required
        $sender_address_line_1  = 'NO. 8 PINTAS TUNA 3,SEBERANG JAYA';

        $sender_address_line_2  = NULL;

        $sender_address_line_3  = NULL;

        $sender_address_line_4  = NULL;

        //Required
        $sender_postcode        = '13700';

        $sender_city            = 'PERAI';

        $sender_state           = 'PULAU PINANG';

        $sender_country_code    = 'MY';

        //Required
        $receiver_name          = 'Maidul Islam';
        //Required
        $receiver_phone         = '+60126920347';

        //Required
        $receiver_email         = 'maidul@email.com';

        $receiver_company_name  = NULL;

        //Required
        $receiver_address_line_1 ='No.16 BK5D/4D,Bandar Kinrara';

        $receiver_address_line_2 =  NULL;

        $receiver_address_line_3 = NULL;

        $receiver_address_line_4 = NULL;

        //Required for domestic
        $receiver_postcode       = '47180';

        $receiver_city           = 'Puchong';

        $receiver_state          = 'Selangor';
        //Requried
        $receiver_country_code   = 'MY';

        //Post Data
        $data = "api_key=$api_key&send_method=$send_method&send_date=$send_date&type=$type&declared_weight=$declared_weight&provider_code=$provider_code&size=$size&length=$length&width=$width&height=$height&content_type=$content_type&content_description=$content_description&content_value=$content_value&sender_name=$sender_name&sender_phone=$sender_phone&sender_address_line_1=$sender_address_line_1&sender_postcode=$sender_postcode&receiver_name=$receiver_name&receiver_phone=$receiver_phone&receiver_email=$receiver_email&receiver_address_line_1=$receiver_address_line_1&receiver_postcode=$receiver_postcode&receiver_country_code=$receiver_country_code";

        $post_url = 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/create_shipment';

        $response = $this->apiPostRequest($post_url,$data);


    return $response;
    }

    public function newCartCheckout($key)
    {
        // $SERVER_API_KEY = 'kf0ecfaac86c2c240ea14d276cee0a4d5';
        // $data = [
        //     'api_key' => $SERVER_API_KEY,
        //     'shipment_keys' => [$key,]
        // ];
        // $dataString = json_encode($data);
        // $headers = [
        //     'Authorization: key=' . $SERVER_API_KEY,
        //     'Content-Type: application/json',
        // ];
        // $ch = curl_init();
        // curl_setopt($ch, CURLOPT_URL, 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/checkout');
        // curl_setopt($ch, CURLOPT_POST, true);
        // curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        // curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);
        // $response = curl_exec($ch);
        // echo '<pre>';
        // echo '======================<br>';
        // print_r($response);
        // echo '<br>======================';
        // exit();
        $data = "api_key=kf0ecfaac86c2c240ea14d276cee0a4d5&shipment_keys=$key";
           // $data                   =' api_key="kf0ecfaac86c2c240ea14d276cee0a4d5","shipment_keys":["'.$key.'",]';
            $curl = curl_init();
            curl_setopt_array($curl, array(
              CURLOPT_URL => 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/checkout',
              CURLOPT_RETURNTRANSFER => true,
              CURLOPT_ENCODING => '',
              CURLOPT_MAXREDIRS => 10,
              CURLOPT_TIMEOUT => 0,
              CURLOPT_FOLLOWLOCATION => true,
              CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
              CURLOPT_CUSTOMREQUEST => 'POST',
              CURLOPT_POSTFIELDS => $data,
              CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded',
              //  'Cookie: ci_session=gi3odq32jirlu6hvm30c26hjrab2cjtu'
              ),
            ));
            $response = curl_exec($curl);
            curl_close($curl);
         return $response;
    }



    public function apiPostRequest($post_url,$data){
        $curl = curl_init();
        curl_setopt_array($curl, array(
          CURLOPT_URL => $post_url,
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $data,
          CURLOPT_HTTPHEADER => array(
        'Content-Type: application/x-www-form-urlencoded',
           // 'Cookie: ci_session=94ve0nk61eimh6pnku7jg2m2s6sbt2kf'
          ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;

    }


    public function apiGetRequest($api_key,$post_url){


    }



    //Get all pending cartlist //To get all shipment that is ready to checkout.

    public function getCartList($request){

        $api_key = 'kf0ecfaac86c2c240ea14d276cee0a4d5';
        $data = "api_key=$api_key";

        $post_url = 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/get_cart_items';

        $data = $this->apiPostRequest($post_url,$data);

        $data = json_decode($data, TRUE);

        if($data['message'] == 'success'){
           // return $this->formatResponse(true, 'Cart Data Loaded !', '', $data);

           return $data;
        }
        else{
            return $this->formatResponse(false, 'Cart Data Loaded !', '', $data);
        }

    }


        //Checkout shipments to get download connote links.
    public function cartCheckout($key)
    {

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/checkout',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => array('api_key' => 'kf0ecfaac86c2c240ea14d276cee0a4d5','shipment_keys' => '".$key."'),
          CURLOPT_HTTPHEADER => array(
           // 'Cookie: ci_session=0progu601kpkg69oobbm8267dmk5bf8a'
          ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);



    echo '<pre>';
    echo '======================<br>';
    print_r($response);
    echo '<br>======================';
    exit();

       return $response;

    }



        //Shipment status value and label to be shown to user
    public function getShipmentStatus(){

        $api_key                = 'kf0ecfaac86c2c240ea14d276cee0a4d5';

        $data                   = "api_key=$api_key";

        $post_url               = 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/get_shipment_statuses';

        $response               = $this->apiPostRequest($post_url,$data);

        $data                   = json_decode($response, TRUE);

        if($data['message'] == 'success'){
            // return $this->formatResponse(true, 'Cart Data Loaded !', '', $data);
            return $data;
         }
         else{

             return false;
         }

    }

    //To get shipment details given an array of shipment_keys.
    public function getShipmentInfoBykey($shipment_keys){

        $data = "api_key=kf0ecfaac86c2c240ea14d276cee0a4d5&shipment_keys=$shipment_keys";

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'http://sendparcel-test.ap-southeast-1.elasticbeanstalk.com/apiv1/get_shipments',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'POST',
          CURLOPT_POSTFIELDS => $data,
          CURLOPT_HTTPHEADER => array(
            'Content-Type: application/x-www-form-urlencoded',
          ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
            //array
       // $shipment_keys	            = ['shipment_keys' => $shipment_keys];
       // $data                       = "api_key=$api_key,shipment_keys=$shipment_keys";
       // $post_url                   = 'https://sendparcel.poslaju.com.my/apiv1/get_shipments';
       // $response                   = $this->apiPostRequest($post_url,$data);
       // $data                       = json_decode($response, TRUE);
       return $response;
    }


///To get list of prices available for the respective shipment intent. Use to show price and shipment options to the user before proceed to complete the shipment details.

    public function checkShipmentPrice($request){

        $api_key                = 'kffc288c0c4039a3de78235efc19332b6';

        $postcode               = $request->sender_postcode;

        $receiver_postcode      = $request->receiver_postcode;

        $receiver_country_code  = $request->receiver_country_code;

        //in KG
        $declared_weight        = $request->declared_weight;

        $post_url               = 'https://sendparcel.poslaju.com.my/apiv1/check_price';

        $data                   = "api_key=$api_key&sender_postcode=$sender_postcode&receiver_postcode=$receiver_postcode&receiver_country_code=$receiver_country_code&declared_weight=$declared_weight";


        $response               = $this->apiPostRequest($post_url,$data);


        $data                   = json_decode($response, TRUE);

        if($data['message'] == 'success'){

            return $data;
         }
         else{

             return false;
         }

    }

    //To verify postcode. If false then the postcode is invalid. Also used to auto populate city and state details for the postcode
    public function getPostcodeDetails($request){

        $api_key                = 'kffc288c0c4039a3de78235efc19332b6';
        $postcode               = $request->sender_postcode;
        $post_url               = 'https://sendparcel.poslaju.com.my/apiv1/get_postcode_details';
        $data                   = "api_key=$api_key&postcode=$postcode";
        $response               = $this->apiPostRequest($post_url,$data);

        $data                   = json_decode($response, TRUE);

        if($data['message'] == 'success'){

            return $data;
         }
         else{

             return false;
         }


    }

    //To get all parcel sizes available to be chosen by user in creating a shipment.
    public function getParcelSizes(){

        $api_key                = 'kffc288c0c4039a3de78235efc19332b6';

        $postcode               = $request->sender_postcode;

        $post_url               = 'https://sendparcel.poslaju.com.my/apiv1/get_parcel_sizes';

        $data                   = "api_key=$api_key";

        $response               = $this->apiPostRequest($post_url,$data);

        $data                   = json_decode($response, TRUE);

        if($data['message'] == 'success'){

            return $data;
         }
         else{

             return false;
         }




    }





    public function getPaginatedList($request, int $per_page = 5)
    {
        $data =  $this->dispatch->get();
        return $this->formatResponse(true, 'Data found successfully !', 'admin.dispatched.list', $data);
    }


    public function getOrderForDisopatch($PK_NO)
    {
        $data       = array();

        $booking    = $this->booking->where('PK_NO',$PK_NO)
        ->first();
        $data['booking']            = $booking;
        return $this->formatResponse(true, 'Data found successfully !', 'admin.booking.list', $data);
    }





}
