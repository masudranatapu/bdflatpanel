<?php

namespace App\Repositories\Admin\Poslazu;

interface PoslazuInterface
{

    public function getConsignmentNote($request);

    public function getTrackingId(int $id);





    public function getPaginatedList($request, int $per_page = 5);
    public function postStore($request);

    public function createShipment($request);
    public function getCartList($request);
    public function cartCheckout($key);
    public function getShipmentStatus();







    // public function delete($id);
    // public function getDueOrdersCustomer(int $id);
    // public function getDueOrdersReseller(int $id);
    // public function findOrThrowException($id);
    // public function ajaxDelete($id);
    // public function ajaxPayment($request);
    // public function updateBooktoOrder($request,$id);
    // public function getIndex();
    public function getOrderForDisopatch($id);
    // public function getCustomerAddress($id,$pk_no);
}
